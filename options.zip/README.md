# truly

![GitHub release (latest by date)](https://img.shields.io/github/downloads/cheese-233/truly/latest/total)

一个真正聚合的开源搜索引擎。

### todo

